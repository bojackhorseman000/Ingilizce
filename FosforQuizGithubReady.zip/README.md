# Fosfor Quiz Android

Fosforlanmamış kelimeler için hazırlanmış Android WebView quiz uygulaması.

Uygulama internetsiz çalışır; quiz `app/src/main/assets/index.html` içine gömülüdür.

## GitHub ile APK üretme

Bu pakette `.github/workflows/build-apk.yml` hazırdır. Projeyi GitHub repository'sine yüklediğinde **Actions** sekmesinden APK otomatik oluşturulur.

Ayrıntılı adımlar: `GITHUB_APK_KURULUM.md`

## Android Studio ile APK üretme

1. Android Studio ile bu klasörü aç.
2. Gradle senkronizasyonunu çalıştır.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` yolunu izle.
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

Paket adı: `com.mete.fosforquiz`
Uygulama adı: `Fosfor Quiz`
