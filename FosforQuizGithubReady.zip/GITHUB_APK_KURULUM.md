# GitHub ile APK oluşturma

Bu proje GitHub Actions ile otomatik APK üretir.

## Telefonda yapılacaklar

1. GitHub'da yeni bir repository oluştur.
2. Bu ZIP'i telefonda çıkar.
3. Repository içine dosyaları yükle. Aşağıdaki klasörlerin kökte olması gerekir:
   - `.github/workflows/build-apk.yml`
   - `app/`
   - `build.gradle`
   - `settings.gradle`
4. Yükleme bitince GitHub'da repository sayfasında **Actions** sekmesine gir.
5. **Build Android APK** adlı workflow'u aç.
6. Çalışma başlamadıysa **Run workflow** düğmesine bas.
7. İşlem bitince en alttaki **Artifacts** bölümünden **FosforQuiz-debug-apk** dosyasını indir.
8. ZIP içinden `app-debug.apk` dosyasını çıkar ve telefona kur.

## APK nerede oluşur?

GitHub Actions içinde üretilen dosya:

`app/build/outputs/apk/debug/app-debug.apk`

İndirilen artifact adı:

`FosforQuiz-debug-apk`

## Not

Bu APK debug APK'dır; telefona kurmak için Android'in “bilinmeyen kaynaklara izin ver” uyarısını onaylaman gerekir.
