# Fosfor Quiz Minimal

AMOLED siyah, sade ve internetsiz çalışan quiz uygulaması.

## Değişiklikler

- Karışık harf / yazma modu kaldırıldı.
- Çoktan seçmeli mod yeniden yazıldı.
- Çoktan seçmelide her soru kilitlenir; doğru/yanlış net görünür.
- Arayüz minimal AMOLED siyah yapıldı.
- WebView, localStorage ve karanlık sistem barları düzeltildi.

## GitHub ile APK

ZIP dosyasını GitHub'a tek parça ZIP olarak yükleme. ZIP'i çıkar ve içindeki klasör/dosyaları repo köküne yükle:

- `.github/`
- `app/`
- `build.gradle`
- `settings.gradle`
- `README.md`

Sonra GitHub'da **Actions > Build Android APK > Run workflow**.
APK artifact adı: `FosforQuiz-minimal-debug-apk`.
